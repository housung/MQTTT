package newClient;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class clientCallBack implements MqttCallback{

	public clientCallBack(client client) {
		// TODO Auto-generated constructor stub
	}
	@Override
	public void connectionLost(Throwable arg0) {
		// TODO Auto-generated method stub
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
		// TODO Auto-generated method stub
	}

	@Override
	public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
		String str = new String(mqttMessage.getPayload(), "UTF-8");
		System.out.println("Client arrived : " + str);   
		manager.tochechkMessage(str);
	}
}
