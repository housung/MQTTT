package newClient;

import java.util.ArrayList;

import javafx.application.Platform;

public class checkMessage extends Thread{
	private ArrayList<String> List;
		
	public checkMessage() {
		List = new ArrayList<String>();
	}
		
	@Override
		public void run() {
		while(true) {
			synchronized (List) {
				if(!List.isEmpty()) {
					String str = List.get(0);
					check(str);
					List.remove(0);
				}
			}
		}	
	}
		
	private void check(String str) {
		String[] arr = str.split("#");
		switch(arr[0]) {
		case "masterConnect":
			manager.publish("MasterToClient","connect#"+manager.getClient().clientId,0);
			System.out.println("masterConnect ����");
			break;
	
			
		//LoadInfo#type#�ν��Ͻ�����#Topic#Qos#Per#Duration#Size#	
		case "LoadInfo":
			if(arr[1].equals(manager.getClient().clientId)) {
				manager.setOption(str);
				switch (arr[2]) {
				case "p":
					manager.getCon().setType("Publish");
					manager.setType("Publish");
					System.out.println("LoadInfo P ����");
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							// TODO Auto-generated method stub
							manager.getCon().numOfMsgPerSec.setText("publish # of msg/sec");
							manager.getCon().instanceIp.setText("publish Instance Id");
							manager.getCon().totalNumOfMsg.setText("publish Total # of Msg");
						}
					});	
					manager.setIC(new InstanceCreator(arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8]));
					
					break;
				case "s":
					manager.getCon().setType("Subscribe");
					manager.setType("Subscribe");
					System.out.println("LoadInfo S ����");
					
					Platform.runLater(new Runnable() {	
						@Override
						public void run() {
							// TODO Auto-generated method stub
							manager.getCon().numOfMsgPerSec.setText("subscribe # of msg/sec");
							manager.getCon().instanceIp.setText("subscribe Instance Id");
							manager.getCon().totalNumOfMsg.setText("subscribe Total # of Msg");
						}
					});
					manager.setIC(new InstanceCreator(arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8]));
					break;
				}
				
			}
			break;
			//�켱���� 
		case "PublishInfo":
			manager.getDuration();
			//�޼����ۼ�ũ�� �෹�̼��� ������ �˷��ش�.
			
		case "stopLoad":
			if(manager.getType().equals("Subscribe")){
			for(int i = 0;i<manager.getIC().getList().size();i++)
			{
				Instance mqtt = (Instance)manager.getIC().getList().get(i);
				mqtt.disconnect();
			}
				manager.publish("MasterToClient","subResult#"+manager.getClient().clientId+"#"
			+manager.getCon().getTotalMsg()+"#"+manager.getCon().getTotalPer(),0);				
			}
			manager.getCon().setPer(manager.getCon().getTotalPer());
			manager.getCon().setTotal(manager.getCon().getTotalMsg());
			
			
			break;
		
		}
	}
		
	public void addMessage(String str) {
		synchronized (List) {
			List.add(str);
		}
	}
}
