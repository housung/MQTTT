package newClient;

import java.util.ArrayList;
import java.util.Timer;

import javafx.application.Platform;

public class pub extends Thread{
	private int persec;
	private long duration;
	private Instance client;
	
	//�и��ʷ� ��������
	
	private long startTime;
	private long newTime=0;
	private long delay = 0L;
	private int count = 0;
	private int Size = 0;
	private String msg;
	private long oldTime = 0;
	
	public pub(Instance client,int persec,int duration,int Size) {
		
		this.client = client;
		this.persec = persec;
		this.duration = (long)duration * 1000; //�и���
		this.delay = (long)((double)(duration)/(persec*duration) *1000);
		msg = new String();
		for(int i =0;i<Size;i++) {
			msg+="a";
		}
		
	}
	
	@Override
	public void run() {
		startTime = System.currentTimeMillis();
		System.out.println(startTime);
		client.pub(client.topic,msg,0);
		count++;
		while(true) {
			//duration �ð� �Ǹ� ����
			synchronized (manager.getCon().list) {
				System.out.println("testTimer"+System.currentTimeMillis());
				manager.getCon().list.get(client.listNum).setTotal(Integer.toString(count));
				manager.getCon().list.get(client.listNum).setNumof(Long.toString((long)(count*1000/((newTime-startTime)))));	
			}
			
			
			if((newTime - startTime)>= duration) 
			{
				System.out.println((long)(((newTime-startTime))));
				System.out.println((long)(count/((newTime-startTime)/1000)));
				manager.getCon().setPer((int)(count/((newTime-startTime)/1000)));
				manager.getCon().setTotal(count);
				break;
			}
			oldTime = newTime;
			newTime = System.currentTimeMillis();
			client.pub(client.topic,msg,0);
			
			count++;
			
			try {
				//System.out.println(count+"delay: "+delay+" test : "+(long)((double)(newTime-startTime)/count));
				//�ӵ��� �̷��� ������ �� ���̋����� �׷������ִ�.
				System.out.println(count + " "+delay+" "+((double)(newTime-startTime)/count));
				
				if(delay + (delay - (long)((double)(newTime-startTime)/count)-1)>0) {
					Thread.sleep((long)(delay + (delay - (long)((double)(newTime-startTime)/count)-1)));
				}
				else
					Thread.sleep(delay);
				
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		manager.publish("MasterToClient","pubResult#"+manager.getClient().clientId+"#"+count+"#"+(long)(count*1000/((newTime-startTime))),0);
	}	
}

