package newClient;


public class manager {
	public static String Main = "LoadTest.fxml";
	private static client client;
	private static Controller con;
	private static String Type;
	private static checkMessage checkMessage;
	private static InstanceCreator InstanceCreator;	
	private static String clientOption;
	
	private static int Duration = 0;
	private static int Per = 0;
	
	public static InstanceCreator getIC() {
		return InstanceCreator;
	}
	
	public static void setClient(client client1) {
		manager.client = client1;	
	}
	
	public static client getClient() {
		return client;
	}
	
	public static void setController(Controller con) {
		manager.con = con;
	}
	
	public static Controller getCon() {
		return con;
	}
	
	public static void publish(String topic,String msg,int retain) {
		Thread t1 = new Thread(new Runnable() {		
			@Override
			public void run() {
				client.pub(topic,msg, retain);
			}
		});
		t1.start();
	}

	public static void setType(String type) {
		Type = type;
	}
	
	public static String getType() {
		return Type;
	}
	
	public static void setCheckMessage(checkMessage cm) {
		checkMessage = cm;
		checkMessage.start();
	}

	public static void tochechkMessage(String str) {
		checkMessage.addMessage(str);
	}
	
	public static void setIC(InstanceCreator ic) {
		InstanceCreator = ic;
		InstanceCreator.start();
	}
	
	public static void startFlag() {
		InstanceCreator.flagOn();
	}
	
	public static void stopFlag() {
		InstanceCreator.flagOff();
	}
	
	public static void setOption(String option) {
		clientOption = option;
	}


	public static void setDuration(int n) {
		Duration = n;
	}
	
	public static void setPer(int n) {
		Per = n;
	}
	
	public static int getPer() {
		return Per;
	}
	
	public static int getDuration() {
		return Duration;
	}
	
}
