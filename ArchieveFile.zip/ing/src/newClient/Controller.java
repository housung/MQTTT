package newClient;

import java.net.URL;
import java.util.ResourceBundle;

import javax.sql.rowset.spi.SyncResolver;
import javax.swing.plaf.metal.MetalBorders.PaletteBorder;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;


public class Controller implements Initializable{
	@FXML Label test;
	@FXML TextField Broker;
	@FXML TextField port;
	@FXML Button Connect;
	@FXML StackPane tableHolder;	//pub/sub ���ο� ���� table �ٲ�
	@FXML Label clientType;	//pub/sub ǥ���� label
	@FXML TableView<Data> List;
	@FXML TableColumn<Data,String> instanceIp;
	@FXML TableColumn<Data, Label> totalNumOfMsg;
	@FXML TableColumn<Data, Label> numOfMsgPerSec;
	
	@FXML TextField total;
	@FXML TextField per;
	
	
	ObservableList<Data>list = FXCollections.observableArrayList();
	
	public void initialize(URL location, ResourceBundle resources) {
		List.setPlaceholder(new Label(""));
		instanceIp.setCellValueFactory(new PropertyValueFactory<Data, String>("id"));
		totalNumOfMsg.setCellValueFactory(new PropertyValueFactory<Data, Label>("total"));
		numOfMsgPerSec.setCellValueFactory(new PropertyValueFactory<Data, Label>("numof"));
		List.setItems(list);
		total.setText("0");
		per.setText("0");
		Broker.setText("127.0.0.1");
		port.setText("1883");
	}
	
	public synchronized void setTotal(int msg) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				total.setText(Integer.toString(msg));
			}
		});
	}
	
	public synchronized void setPer(int p) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				per.setText(Integer.toString(p));
			}
		});
	}
	
	
	public void connectOn() {
		Broker.setDisable(true);
		port.setDisable(true);
		Connect.setDisable(true);
		manager.setCheckMessage(new checkMessage());
		manager.setClient(new client(Broker.getText()+":"+port.getText()));
	}	
	
	public void setType(String type) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				clientType.setText(type);
			}
		});
	}
	
	public void putList(String i,String t) {
		list.add(new Data(i,new Label(t)));
	}
	
	public int getTotalMsg() {
		int sum = 0;
		for(int i=0;i<list.size();i++) {
			sum+=Integer.parseInt(list.get(i).getTotal().getText());
		}
		return sum/list.size();
	}
	
	public int getTotalPer() {
		int sum = 0;
		for(int i=0;i<list.size();i++) {
			sum+=Integer.parseInt(list.get(i).getNumof().getText());
		}
		return sum/list.size();
	}
}


