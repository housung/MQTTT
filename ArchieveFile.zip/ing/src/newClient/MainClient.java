package newClient;
	
import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainClient extends Application {
	private static Stage stage;
	
	public static void setSize(double width,double height) {
		stage.setWidth(width);
		stage.setHeight(height);
		stage.show();
	}
	
	@Override
	public void start(Stage primaryStage) {
		try {		
			stage = primaryStage;
			primaryStage.setTitle("LoadTest-Client");	
			primaryStage.setScene(createScene(loadMainPane()));
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws SocketException, UnknownHostException {
		launch(args);
	}
	
	private BorderPane loadMainPane() throws IOException{
		FXMLLoader loader = new FXMLLoader();
		BorderPane mainPane = (BorderPane) loader.load(getClass().getResourceAsStream(manager.Main));
		Controller Controller = loader.getController();
		manager.setController(Controller);
		return mainPane;
	}
	
	private Scene createScene(BorderPane mainPane) {
		Scene scene = new Scene(mainPane);
		scene.getStylesheets().add(MainClient.class.getResource("bootstrap3.css").toExternalForm());
		return scene;
	}
}

