package newClient;

import javafx.application.Platform;
import javafx.scene.control.Label;

public class Data {
	String id;
	Label total;
	Label numof;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Label getTotal() {
		return total;
	}
	public void setTotal(String t) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				total.setText(t);
				
			}
		});
	}
	public Label getNumof() {
		return numof;
	}
	
	public void setNumof(String n) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				numof.setText(n);
			}
		});
	}
	
	public Data(String id,Label total) {
		this.id = id;
		this.total =  total;
		this.total.setText("0");
		this.numof = new Label("0");
	}
	
}
