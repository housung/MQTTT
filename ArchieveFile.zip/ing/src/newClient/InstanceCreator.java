package newClient;

import java.util.ArrayList;

public class InstanceCreator extends Thread{
	private int StartFlag = 0;
	private String type;
	private int numOfInstance;
	private String Topic;
	private int Qos;
	private int Per;
	private int Duration;
	private int size;
	
	private ArrayList<Object> List;
	//����Ʈ�� ���� �ν��Ͻ����� �����Ҽ��ְԲ� ��Ʈ������!
	//
	
	public ArrayList<Object>getList() {
		return List;
	}
	
	//LoadInfo#type#�ν��Ͻ�����#Topic#Qos#Per#Duration#Size#
	public InstanceCreator(String type,String numOfInstance,String topic,String qos,String per,String duration,String size){
		this.type = type;
		this.numOfInstance = Integer.parseInt(numOfInstance);
		this.Topic = topic;
		this.Duration = Integer.parseInt(duration);
		this.size = Integer.parseInt(size);
		this.Qos = Integer.parseInt(qos);
		this.Per = Integer.parseInt(per);
		List = new ArrayList<Object>();
	}

	@Override
	public void run() {
		//�ν��Ͻ� �����ϱ�
		System.out.println("InstanceCreator Test start");
		if(type.equals("s")){
			for(int i = 0;i<numOfInstance;i++) {
				List.add(new Instance(manager.getClient().clientId+"-s-"+i,manager.getClient().broker,Topic,type));
				
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			manager.publish("MasterToClient","subReady" ,0);		
		}
		//üũ�ϱ�
		//��������� ���? �Ѳ�����?
		
		
		else if(type.equals("p")) {
			for(int i = 0;i<numOfInstance;i++) {
			pub tmp	= new pub(new Instance(manager.getClient().clientId+"-p-"+i,
						manager.getClient().broker,Topic,type),Per,Duration,size);
			List.add(tmp);
			tmp.start();
			}
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//�����ͷκ��� ��ŸƮ ��ȣ�� ���� ����
		System.out.println("InstanceCreator Test Clear");
	}
	
	public void flagOn() {
		StartFlag = 1;
	}

	public void flagOff() {
		StartFlag = 0;
	}

	public boolean isStart() {
		if(StartFlag == 1) 
			return true;
		else 
			return false;
	}
}
