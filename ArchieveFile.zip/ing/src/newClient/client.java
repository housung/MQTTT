package newClient;

import java.net.InetAddress;
import java.net.UnknownHostException;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class client {
		   String topic        = "MasterToClient";
	       String content;
	       int qos             = 0;
	       String broker = "";
	       String clientId;
	       MemoryPersistence persistence;
	       MqttClient sampleClient;
	       MqttConnectOptions connOpts;
	       
	       
	       public client(String str) {
	    	   try {
					clientId = InetAddress.getLocalHost().getHostAddress();
				} catch (UnknownHostException e) {
					
					e.printStackTrace();
				}
	    	   try {
	    		   	//clientId = "192.168.0.27";
	    		   	broker = "tcp://"+str;
	    		   	persistence = new MemoryPersistence();
	               	sampleClient = new MqttClient(broker,clientId, persistence);
		    	   	connOpts = new MqttConnectOptions();
		           	connOpts.setCleanSession(true);
		           	sampleClient.connect(connOpts);
		           	sampleClient.setCallback(new clientCallBack(this));
		            sub(topic);
	        	   } catch(MqttException me) {
	               System.out.println("reason "+me.getReasonCode());
	               System.out.println("msg "+me.getMessage());
	               System.out.println("loc "+me.getLocalizedMessage());
	               System.out.println("cause "+me.getCause());
	               System.out.println("excep "+me);
	               me.printStackTrace();
	        	   }
	       }
		
	       public void pub(String topic,String str,int retain) {
	  		 MqttMessage message = new MqttMessage(str.getBytes());
	  		switch(retain){
	  		case 0:
	  			 message.setRetained(false);
	  			break;
	  		case 1:
	  			 message.setRetained(true);
	  			break;
	  		}
	           message.setQos(qos);
	           try {
	          	 sampleClient.publish(topic, message);  
	           } catch(MqttException me) {
	             System.out.println("reason "+me.getReasonCode());
	             System.out.println("msg "+me.getMessage());
	             System.out.println("loc "+me.getLocalizedMessage());
	             System.out.println("cause "+me.getCause());
	             System.out.println("excep "+me);
	             me.printStackTrace();
	           }
	  	}
	       
		public void sub(String topic) {
			        try {
			            sampleClient.subscribe(topic,qos);
			        } catch (MqttException me) {
			        	  System.out.println("reason "+me.getReasonCode());
			              System.out.println("msg "+me.getMessage());
			              System.out.println("loc "+me.getLocalizedMessage());
			              System.out.println("cause "+me.getCause());
			              System.out.println("excep "+me);
			              me.printStackTrace();
			              
			        }
		}
		
		public void disconnect() {
			try {
				sampleClient.disconnect();
			   } catch(MqttException me) {
	               System.out.println("reason "+me.getReasonCode());
	               System.out.println("msg "+me.getMessage());
	               System.out.println("loc "+me.getLocalizedMessage());
	               System.out.println("cause "+me.getCause());
	               System.out.println("excep "+me);
	               me.printStackTrace();
	           }
		}
		
	}