package newClient;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class Instance {
		   String topic        = "";
	       String content;
	       int qos             = 0;
	       String broker = "";
	       String clientId;
	       MemoryPersistence persistence;
	       MqttClient sampleClient;
	       MqttConnectOptions connOpts;
	       String type;
	       int count = 0;
	       long startTime = 0;
	       int listNum;
	     
	       
	       public Instance(String id,String broker,String topic,String type) {
	    	   try {
	    		   clientId = id;
	    		   this.topic = topic;
	    		   this.type = type;
	    		   this.broker = broker;
	    		   persistence = new MemoryPersistence();
	               sampleClient = new MqttClient(broker,clientId, persistence);
		    	   connOpts = new MqttConnectOptions();
		           connOpts.setCleanSession(true);
		           sampleClient.connect(connOpts);
		           sampleClient.setCallback(new callback());
		           
		           	if(type.equals("s")) {
		           		synchronized (manager.getCon().list) {
		           			listNum = manager.getCon().list.size();	
						}
		           		manager.getCon().putList(clientId,"0");
		           		sampleClient.subscribe(topic);
		           		startTime = System.currentTimeMillis();
		           	}
		           	else if(type.equals("p")) {
		           		synchronized (manager.getCon().list) {
		           			listNum = manager.getCon().list.size();	
						}
		           		manager.getCon().putList(clientId,"0");
		           	}
		           	
	        	   } catch(MqttException me) {
	               System.out.println("reason "+me.getReasonCode());
	               System.out.println("msg "+me.getMessage());
	               System.out.println("loc "+me.getLocalizedMessage());
	               System.out.println("cause "+me.getCause());
	               System.out.println("excep "+me);
	               me.printStackTrace();
	        	   }
	       }
		
	       public void pub(String topic,String str,int retain) {
	  		 MqttMessage message = new MqttMessage(str.getBytes());
	  		switch(retain){
	  		case 0:
	  			 message.setRetained(false);
	  			break;
	  		case 1:
	  			 message.setRetained(true);
	  			break;
	  		}
	           message.setQos(qos);
	           try {
	          	 sampleClient.publish(topic, message);  
	           } catch(MqttException me) {
	             System.out.println("reason "+me.getReasonCode());
	             System.out.println("msg "+me.getMessage());
	             System.out.println("loc "+me.getLocalizedMessage());
	             System.out.println("cause "+me.getCause());
	             System.out.println("excep "+me);
	             me.printStackTrace();
	           }
	  	}
	       
		public void sub(String topic) {
			        try {
			            sampleClient.subscribe(topic,qos);
			        } catch (MqttException me) {
			        	  System.out.println("reason "+me.getReasonCode());
			              System.out.println("msg "+me.getMessage());
			              System.out.println("loc "+me.getLocalizedMessage());
			              System.out.println("cause "+me.getCause());
			              System.out.println("excep "+me);
			              me.printStackTrace();
			        }
		}
		
		public void disconnect() {
			try {
				System.out.println(clientId+"end");
				sampleClient.disconnect();
			   } catch(MqttException me) {
	               System.out.println("reason "+me.getReasonCode());
	               System.out.println("msg "+me.getMessage());
	               System.out.println("loc "+me.getLocalizedMessage());
	               System.out.println("cause "+me.getCause());
	               System.out.println("excep "+me);
	               me.printStackTrace();
	           }
		}
		
		private class callback implements MqttCallback {

			@Override
			public void connectionLost(Throwable arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void deliveryComplete(IMqttDeliveryToken arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void messageArrived(String arg0, MqttMessage arg1) throws Exception {
				// TODO Auto-generated method stub
				count++;
				int per = (int)(count/((System.currentTimeMillis()-startTime)/1000));
				synchronized (manager.getCon().list) {
					manager.getCon().list.get(listNum).setNumof(Integer.toString(per));
					manager.getCon().list.get(listNum).setTotal(Integer.toString(count));	
				}
				System.out.println(listNum+":"+clientId+ " :"+per);
			}
			
		}
		
	}
