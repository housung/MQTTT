package newForm;

public class runningTime extends Thread{
	//�ð� ������ ����ٴ°� �˰����� ¥���־���
	private Long OldTime = 0L;
	private Long newTime = 0L;
	private Long runTime = 0L;
	@Override
	public void run() {
		OldTime = System.currentTimeMillis();
		do {
			try {
				newTime = System.currentTimeMillis();
				runTime = (newTime - OldTime);
				manager.getCon().setRunTime(SecDotMilli(Long.toString(runTime)));
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
		}while(true);
	}
	

	public String SecDotMilli(String milli) {
		String str;
		if(milli.equals("0"))
			return milli;
		int len = milli.length();
		str = milli.substring(0,len-3) + "." + milli.substring(len-3,len);
				return str;
	}
}
