package newForm;

import java.util.ArrayList;

import javafx.application.Platform;

public class manager {
	public static String Main = "LoadTest.fxml";
	
	private static master master;
	
	private static Controller con;
	private static ArrayList<String> clientList = new ArrayList<String>();
	private static checkMessage checkMessage;
	private static runningTime runningTime;

	private static int PubresultCount = 0;
	private static int SubresultCount = 0;
	
	
	private static int Subscriber = 0;
	private static int Publisher = 0;
	private static int Counting =0;
	
	private static int readyFlag = 0;
	
	private static int SubtotalMsg = 0;
	private static int SubtotalPer = 0;
	
	private static int PubtotalMsg = 0;
	private static int PubtotalPer = 0;
	
	
	public synchronized static void PubresultCounting() {
		PubresultCount++;
		if(PubresultCount==Publisher) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					con.pTotalNumOfMsg.setText(Integer.toString(manager.getPubTotalPer()/Publisher));
					con.pNumOfMsgPerSec.setText(Integer.toString(manager.getPubTotalMsg()/Publisher));
					manager.publish("MasterToClient","stopLoad",1);
				}
			});
			return;
		}
	}
	
	public synchronized static void SubresultCounting() {
			SubresultCount++;
		if(SubresultCount==Subscriber) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					con.sTotalNumOfMsg.setText(Integer.toString(manager.getSubTotalPer()/Subscriber));
					con.sNumOfMsgPerSec.setText(Integer.toString(manager.getSubTotalMsg()/Subscriber));
					// �ð��� �����.
					runningTime.interrupt();
				}
			});
			return;
		}
	}
	
	public static void setMqtt(master master1) {
		manager.master = master1;
	}
	
	public static void publish(String topic, String str,int retain) {
		Thread t1 = new Thread(new Runnable() {
			@Override
			public void run() {
				master.pub(topic,str,retain);
			}
		});
		
		t1.start();
		//���� �ݹ鿡�� �����ϴ�. �������ϸ� �켱 ������ �ʽ��ϴ�.
	}
	
	public static void setController(Controller con) {
		manager.con = con;
	}
	
	public static Controller getCon() {
		return con;
	}
	
	public static void addClient(String str) {
		synchronized (clientList) {
			clientList.add(str); 
			manager.getCon().setClientNum(clientList.size());
			manager.getCon().putList(str);
		}
	}
	
	public static int getSize() {
		synchronized (clientList) {
			return clientList.size();
		}
	}
	
	public static void setcheckMessage(checkMessage cm) {
		checkMessage = cm;
		checkMessage.start();
	}
	
	public static void tochechkMessage(String str) {
		checkMessage.addMessage(str);
	}

	public static void setRunningTime(runningTime runTime) {
		runningTime = runTime;
		runningTime.start();
	}
	
	public synchronized static void setreadyFlag(int i) {
			readyFlag = i;
	}
	//comming sub
	public synchronized static void countSub() {	
		if(Subscriber==0) {
			readyFlag=1;
			return;
		}
		Counting++;
		if(Subscriber==Counting) {
			readyFlag=1;
		}
	}
	
	public synchronized static void PublisherCounting() {
		Publisher++;
		
	}
	
	public synchronized static void SubscribeCounting() {
		Subscriber++;
	}
	
	public synchronized static boolean getreadyFlag() {
		if(readyFlag==0)
			return false;
		return true;
	}
	
	public static int getPublisher() {
		return Publisher;
	}
	
	public static int getSubscribe() {
		return Subscriber;
	}
	
	public static void addSubTotalMsg(int num) {
		SubtotalMsg+=num;
	}
	
	public static void addSubTotalPer(int num) {
		SubtotalPer+=num;
	}
	
	public static void addPubTotalMsg(int num) {
		PubtotalMsg+=num;
	}
	
	public static void addPubTotalPer(int num) {
		PubtotalPer+=num;
	}
	
	public static int getSubTotalMsg() {
		return SubtotalMsg;
	}
	
	public static int getSubTotalPer() {
		return SubtotalPer;
	}
	
	public static int getPubTotalMsg() {
		return PubtotalMsg;
	}
	
	public static int getPubTotalPer() {
		return PubtotalPer;
	}
	
	public static void pause() {
		//Ŭ���̾�Ʈ�� ������ ����
		if(runningTime!=null) {
			runningTime.interrupt();
		}
		
		if(checkMessage!=null) {
			checkMessage.interrupt();
		}
		
		clearOptions();
	}
	
	public static void disconnectMaster() {
		master.disconnect();
		master = null;
	}
	
	public static void clearOptions() {
		con = null;
		clientList = null;
		checkMessage = null;
		runningTime = null;;

		PubresultCount = 0;
		SubresultCount = 0;
		Subscriber = 0;
		Publisher = 0;
		Counting =0;
		readyFlag = 0;
		SubtotalMsg = 0;
		SubtotalPer = 0;
		PubtotalMsg = 0;
		PubtotalPer = 0;
	}
}


