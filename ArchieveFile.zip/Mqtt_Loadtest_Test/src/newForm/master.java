package newForm;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class master{
	   int type;
	   String topic        = "MasterToClient";
       String content;
       int qos             = 0;
       String broker = "";
       String clientId     = "LoadMaster";
       MemoryPersistence persistence;
       MqttClient sampleClient;
       MqttConnectOptions connOpts;
     
       public master(String str) {
    	   try {
    		   broker = "tcp://"+str;
        	   persistence = new MemoryPersistence();
               sampleClient = new MqttClient(broker,clientId+"sub", persistence);
               connOpts = new MqttConnectOptions();
               connOpts.setCleanSession(true);
               sampleClient.connect(connOpts);
               sampleClient.setCallback(new SubCallBack());
               sub(topic);
               pub(topic,"masterConnect",1);
        	   } catch(MqttException me) {
               System.out.println("reason "+me.getReasonCode());
               System.out.println("msg "+me.getMessage());
               System.out.println("loc "+me.getLocalizedMessage());
               System.out.println("cause "+me.getCause());
               System.out.println("excep "+me);
               me.printStackTrace();
        	   }
       }
	
	public void pub(String topic,String str,int retain) {
		 MqttMessage message = new MqttMessage(str.getBytes());
		switch(retain){
		case 0:
			 message.setRetained(false);
			break;
		case 1:
			 message.setRetained(true);
			break;
		}
         message.setQos(qos);
         try {
        	 sampleClient.publish(topic, message);  
         } catch(MqttException me) {
           System.out.println("reason "+me.getReasonCode());
           System.out.println("msg "+me.getMessage());
           System.out.println("loc "+me.getLocalizedMessage());
           System.out.println("cause "+me.getCause());
           System.out.println("excep "+me);
           me.printStackTrace();
         }
	}
	public void sub(String topic) {
		        try {
		            sampleClient.subscribe(topic,qos);
		        } catch (MqttException me) {
		        	  System.out.println("reason "+me.getReasonCode());
		              System.out.println("msg "+me.getMessage());
		              System.out.println("loc "+me.getLocalizedMessage());
		              System.out.println("cause "+me.getCause());
		              System.out.println("excep "+me);
		              me.printStackTrace();
		        }
	}
	
	
	
	public void disconnect() {
		try {
			pub("MasterToClient","masterDisconnect",1);
			sampleClient.disconnect();
		   } catch(MqttException me) {
               System.out.println("reason "+me.getReasonCode());
               System.out.println("msg "+me.getMessage());
               System.out.println("loc "+me.getLocalizedMessage());
               System.out.println("cause "+me.getCause());
               System.out.println("excep "+me);
               me.printStackTrace();
           }
	}
	
}
