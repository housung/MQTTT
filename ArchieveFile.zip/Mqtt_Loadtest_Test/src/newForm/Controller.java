package newForm;

import java.net.URL;
import java.util.ResourceBundle;

import javax.sound.sampled.Port;

import com.sun.javafx.webkit.ThemeClientImpl;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class Controller implements Initializable{
	//����
	@FXML TextField ip;
//	@FXML Button setIp;
	@FXML Button Start;
//	@FXML Button setPort;
	@FXML TextField port;
	@FXML Button setBroker;
	
	@FXML TextField duration;
	@FXML Label Runtime;
	
	
	//���̺�
	@FXML TableView<Data> List;
	@FXML TableColumn<Data,Integer> No;
	@FXML TableColumn<Data,TextField> Instance;
	@FXML TableColumn<Data,String> Ip;
	@FXML TableColumn<Data, CheckBox>Publish;
	@FXML TableColumn<Data, CheckBox>Subscribe;
	@FXML TableColumn<Data, CheckBox>Global;
	@FXML TableColumn<Data, TextField>Per;
	@FXML TableColumn<Data, ChoiceBox<String>>Qos;
	@FXML TableColumn<Data, TextField>Size;
	@FXML TableColumn<Data, Label>Result;
	@FXML TableColumn<Data, TextField>Topic;
	@FXML TableColumn<Data, TextField> Duration;
	
	//statistic
	@FXML Label numOfClients;
	@FXML Label numOfSub;
	@FXML Label numOfPub;
	@FXML Label result;
	@FXML Label pNumOfMsgPerSec;
	@FXML Label sTotalNumOfMsg;
	@FXML Label pTotalNumOfMsg;
	@FXML Label sNumOfMsgPerSec;

	
	//global ����
	@FXML TextField getInstance;
	@FXML ChoiceBox<String> getQos;
	@FXML TextField getSec;
	@FXML CheckBox getSub;
	@FXML CheckBox getPub;
	@FXML TextField getTopic;
	@FXML TextField getDuration;
	@FXML TextField getSize;
		
	ObservableList<Data>list = FXCollections.observableArrayList();
	ObservableList<String>qosList = FXCollections.observableArrayList("0","1","2");
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		manager.setController(this);

		List.setPlaceholder(new Label(""));
		No.setCellValueFactory(new PropertyValueFactory<Data, Integer>("No"));
		Instance.setCellValueFactory(new PropertyValueFactory<Data, TextField>("Instance"));
		Ip.setCellValueFactory(new PropertyValueFactory<Data, String>("Ip"));
		Publish.setCellValueFactory(new PropertyValueFactory<Data, CheckBox>("P"));
		Subscribe.setCellValueFactory(new PropertyValueFactory<Data, CheckBox>("S"));
		Global.setCellValueFactory(new PropertyValueFactory<Data, CheckBox>("Global"));
		Qos.setCellValueFactory(new PropertyValueFactory<Data, ChoiceBox<String>>("Qos"));
		Topic.setCellValueFactory(new PropertyValueFactory<Data, TextField>("Topic"));
		Per.setCellValueFactory(new PropertyValueFactory<Data, TextField>("Per"));
		Size.setCellValueFactory(new PropertyValueFactory<Data, TextField>("Size"));
		Result.setCellValueFactory(new PropertyValueFactory<Data, Label>("Result"));
		Duration.setCellValueFactory(new PropertyValueFactory<Data, TextField>("Duration"));
		
		getQos.setItems(qosList);
		getQos.setValue("0");
		List.setItems(list);
		
		ip.setText("127.0.0.1");
		port.setText("1883");
	 }		
	
	public void onMqttMaster() {
		if(setBroker.getText().equals("setBroker")) {
			setBroker.setText("disconnect");
			manager.setcheckMessage(new checkMessage());
			master master1 = new master(ip.getText()+":"+port.getText());
			manager.setMqtt(master1);
			ip.setDisable(false);
			port.setDisable(false);
		}
		else if(setBroker.getText().equals("disconnect")) {
			manager.publish("MasterToClient","masterDisconnect",1);
			setBroker.setText("setBroker");
			
			manager.disconnectMaster();
			manager.pause();
			
//			Ip.setEditable(false);
//			port.setEditable(false);
//			setIp.setDisable(false);
//			setPort.setDisable(false);
		}
	}
	
	/*public void onIp() {
		ip.setEditable(true);
		setIp.setDisable(true);
	}
	
	public void onPort() {
		port.setEditable(true);
		setPort.setDisable(true);
	}*/
	
	public void startLoadTest() {
		if(Start.getText().equals("START")) {
		manager.setRunningTime(new runningTime());
		Start.setText("STOP");
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				synchronized (list) {
					System.out.println("testSub");
					for(int i = 0;i<list.size();i++) {
						Data tmp = list.get(i);
						String form = sendInfo(tmp);
						if(form.split("#")[2].equals("s")) {
							manager.publish("MasterToClient",form,0);	
							manager.SubscribeCounting();
						}
					}
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							manager.getCon().numOfSub.setText(Integer.toString(manager.getSubscribe()));
						}
					});
					
					while(true) { 
							if(manager.getreadyFlag()) {
								System.out.println("change");
								break;
							}
					}
					System.out.println("testPub");
					for(int i = 0;i<list.size();i++) {
						Data tmp = list.get(i);
						String form = sendInfo(tmp);
						if(form.split("#")[2].equals("p")) {
							manager.publish("MasterToClient",form,0);	
							manager.PublisherCounting();
						}
					}
					
					Platform.runLater(new  Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							manager.getCon().numOfPub.setText(Integer.toString(manager.getPublisher()));
							System.out.println(manager.getPublisher());
						}
					});
				}
				
			}
		}).start();
		}
		else if(Start.getText().equals("STOP")) {
			Start.setText("START");
			manager.publish("MasterToClient","pause",1);
			manager.pause();
			resetAll();
		}
	}
	
	public void setClientNum(int num) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				numOfClients.setText(Integer.toString(num));
			}
		});
	}
	
	public void setRunTime(String time) {
		Platform.runLater(new Runnable(){
			@Override
			public void run() {
				Runtime.setText(time);
			}
		});
	}
	
	//LoadInfo#type#�ν��Ͻ�����#Topic#Qos#Per#Duration#Size#
	
	public String sendInfo(Data tmp) {
		String form = "LoadInfo#"+tmp.getIp()+"#";
		
		if(tmp.getGlobal().isSelected()) {
			if(getSub.isSelected()) {
				form+=("s#"
						+getInstance.getText()+"#"
						+getTopic.getText()+"#"
						+getQos.getValue()+"#"
						+"0#"
						+"0#"
						+"0"
						);
			}
			else if(getPub.isSelected()){
				form+=("p#"
						+getInstance.getText()+"#"
						+getTopic.getText()+"#"
						+getQos.getValue()+"#"
						+getSec.getText()+"#"
						+getDuration.getText()+"#"
						+getSize.getText());
			}
		}
		else {
			if(tmp.getS().isSelected()) {
				form+=("s#"
						+tmp.getInstance().getText()+"#"
						+tmp.getTopic().getText()+"#"
						+tmp.getQos().getValue()
						+"#0#0#0");
				
			}
			else if(tmp.getP().isSelected()){
				form+=("p#"
						+tmp.getInstance().getText()+"#"
						+tmp.getTopic().getText()+"#"
						+tmp.getQos().getValue()+"#"
						+tmp.getPer().getText()+"#"
						+tmp.getDuration().getText()+"#"
						+tmp.getSize().getText());
			}
		}
		return form;
	}
	
	public void putList(String str) {
		CheckBox g = new CheckBox();//�۷ι�
		CheckBox p = new CheckBox();//��
		CheckBox s = new CheckBox();//��
		ChoiceBox<String> q = new ChoiceBox<String>(qosList); //ť����
		TextField i = new TextField();//�ν��Ͻ� 
		TextField m = new TextField();//�޼����ӵ�?
		TextField t = new TextField();//����
		TextField d = new TextField();//�෹�̼�
		Label r = new Label();
		
		TextField size = new TextField();//������	
		
		g.selectedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if(g.isSelected()) {
					p.setDisable(true);
					p.setSelected(false);
					s.setDisable(true);
					s.setSelected(false);
					q.setDisable(true);
					i.setDisable(true);
					m.setDisable(true);
					t.setDisable(true);
					d.setDisable(true);
					size.setDisable(true);	
				}
				else {
					p.setDisable(false);
					s.setDisable(false);
					q.setDisable(false);
					i.setDisable(false);
					m.setDisable(false);
					t.setDisable(false);
					d.setDisable(false);
					size.setDisable(false);
				}
			}
		});
		
		p.selectedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if(p.isSelected()) {	
				
					s.setDisable(true);
					g.setDisable(true);
				}
				else {
					s.setDisable(false);
					g.setDisable(false);
				}
			}
				
		});
		
		s.selectedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if(s.isSelected()) {				
					p.setDisable(true);
					g.setDisable(true);
					m.setDisable(true);
					size.setDisable(true);
					d.setDisable(true);
				}
				else {
					p.setDisable(false);
					g.setDisable(false);
					m.setDisable(false);
					size.setDisable(false);
					d.setDisable(false);
				}
			}
		});
		
		q.setValue("0");
		synchronized (list) {
			list.add(new Data(g,
					manager.getSize(),
					str,
					p,
					s,
					t,
					q,
					m,
					i,
					size,
					r,
					d
					));
			}
		}
	
	public void resetAll() {
		list.clear();
		Runtime.setText("");
		
		numOfClients.setText("0");;
		numOfSub.setText("0");
		numOfPub.setText("0");
		pNumOfMsgPerSec.setText("0");
		sTotalNumOfMsg.setText("0");
		pTotalNumOfMsg.setText("0");
		sNumOfMsgPerSec.setText("0");
		
		getInstance.setText("");
		getSec.setText("");
		getSub.setSelected(false);
		getPub.setSelected(false);
		getTopic.setText("");
		getDuration.setText("");
		getSize.setText("");	
	}
}		

