package newForm;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Screen;
import javafx.stage.Stage;


public class MainMaster extends Application {
	private static Stage stage;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			  primaryStage.setTitle("LoadTest-Master");   
		      primaryStage.setScene(createScene(loadMainPane()));
		      primaryStage.setMaximized(true);	//full size
		      primaryStage.show();
		      } 
			  catch(Exception e) {
		         e.printStackTrace();
		     }
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	private BorderPane loadMainPane() throws IOException{
		FXMLLoader loader = new FXMLLoader();
		BorderPane mainPane = (BorderPane) loader.load(getClass().getResourceAsStream(manager.Main));
		mainPane.setMinSize(100, 100);
		mainPane.setMaxSize(1314, 922);
		mainPane.autosize();
		Controller Controller = loader.getController();
		manager.setController(Controller);
		return mainPane;
	}
	
	private Scene createScene(BorderPane mainPane) {
		Scene scene = new Scene(mainPane);
		scene.getStylesheets().add(MainMaster.class.getResource("bootstrap3.css").toExternalForm());
		return scene;
	}
}

