package newForm;

import javafx.application.Platform;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Data {
	
	public int No;
	public CheckBox Global;
	public String Ip;
	public CheckBox P;
	public CheckBox S;
	public TextField Instance;
	public ChoiceBox<String>Qos;
	public TextField Topic;
	public TextField Per;
	public TextField Size;
	public Label Result;
	public TextField Duration;
	
	
	public Data(CheckBox Global,int No,String Ip,CheckBox P,CheckBox S,TextField Topic,ChoiceBox<String> Qos,
			TextField Per,TextField Instance,TextField Size, Label Result, TextField Duration) {
		this.No = No;
		this.Ip = Ip;
		this.Global =  Global;
		this.P = P;
		this.S = S;
		this.Topic = Topic;
		this.Qos = Qos;
		this.Per = Per;
		this.Instance = Instance;
		this.Size = Size;
		this.Result = Result;
		this.Duration = Duration;
		
	}
	
	public int getNo() {
		return No;
	}

	public void setNo(int no) {
		No = no;
	}

	public CheckBox getGlobal() {
		return Global;
	}

	public TextField getDuration() {
		return Duration;
	}

	public void setDuration(TextField duration) {
		Duration = duration;
	}

	public void setQos(ChoiceBox<String> qos) {
		Qos = qos;
	}

	public void setGlobal(CheckBox global) {
		Global = global;
	}

	public String getIp() {
		return Ip;
	}

	public void setIp(String ip) {
		Ip = ip;
	}

	public CheckBox getP() {
		return P;
	}

	public void setP(CheckBox p) {
		P = p;
	}

	public CheckBox getS() {
		return S;
	}

	public void setS(CheckBox s) {
		S = s;
	}

	public TextField getInstance() {
		return Instance;
	}

	public void setInstance(TextField instance) {
		Instance = instance;
	}

	public ChoiceBox<String> getQos() {
		return Qos;
	}

	public TextField getTopic() {
		return Topic;
	}

	public void setTopic(TextField topic) {
		Topic = topic;
	}

	public TextField getPer() {
		return Per;
	}

	public void setPer(TextField per) {
		Per = per;
	}
	
	public void setSize(TextField size) {
		Size =size;
	}
	public void setResult(String result) {
		Platform.runLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Result.setText(result);
			}
		});
	}

	public TextField getSize() {
		return Size;
	}
	public Label getResult() {
		return Result;
	}
	
	

}
