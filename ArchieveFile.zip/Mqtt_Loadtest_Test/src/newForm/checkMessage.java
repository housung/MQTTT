package newForm;

import java.util.ArrayList;

import javafx.application.Platform;

public class checkMessage extends Thread{
	private ArrayList<String> List;
	public checkMessage() {
		List = new ArrayList<String>();
	}
	
	@Override
	public void run() {
		while(true) {
			synchronized (List) {
				if(!List.isEmpty()) {
					String str = List.get(0);
					check(str);
					List.remove(0);
				}
			}
		}	
	}
	
	private void check(String str) {
		String[] arr = str.split("#");
		System.out.println("Check"+str);
		switch(arr[0]) {
		case "connect":
				manager.addClient(arr[1]);
			break;
		case "subReady":
			System.out.println("subReady");
			manager.countSub();
			
			break;
		case "pubReady":
			System.out.println("pubReady");
			manager.publish("MasterToClient","startLoad",1);
			
			break;
			
		case "pubResult":
			for(int i =0;i<manager.getCon().list.size();i++) {
				synchronized (manager.getCon()) {
					if(manager.getCon().list.get(i).getIp().equals(arr[1])) {
							manager.addPubTotalMsg(Integer.parseInt(arr[3]));
							manager.addPubTotalPer(Integer.parseInt(arr[2]));
							
							manager.getCon().list.get(i).setResult(arr[3]);
							//manager.getCon().pTotalNumOfMsg.setText(Integer.toString(manager.getPubTotalMsg()));
							//manager.getCon().pNumOfMsgPerSec.setText(Integer.toString(manager.getPubTotalMsg()));
							manager.PubresultCounting();
							System.out.println("total:"+manager.getPubTotalMsg()+"per:"+manager.getPubTotalPer()+"i"+i+":"+manager.getCon().list.get(i).getResult().getText());
					}
				}	
			}
			
			break;
		case "subResult":
			for(int i =0;i<manager.getCon().list.size();i++) {
				synchronized (manager.getCon()) {
					if(manager.getCon().list.get(i).getIp().equals(arr[1])) {
								manager.addSubTotalMsg(Integer.parseInt(arr[3]));
								manager.addSubTotalPer(Integer.parseInt(arr[2]));
					
								manager.getCon().list.get(i).setResult(arr[3]);
								manager.SubresultCounting();
								//manager.getCon().sTotalNumOfMsg.setText(Integer.toString(manager.getSubTotalMsg()));
								//manager.getCon().sNumOfMsgPerSec.setText(Integer.toString(manager.getSubTotalMsg()));					
							}
					}
					
			}
		}
	}
	
	public void addMessage(String str) {
		synchronized (List) {
			List.add(str);
		}
	}
}
